let x=30,y=150;
var z=x+y;
console.log("Sum of x+y is:",z);
document.write("Sum of x+y is:",z);
