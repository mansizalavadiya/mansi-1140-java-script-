let name=prompt(" Hello, What is your name?");
document.write(name);